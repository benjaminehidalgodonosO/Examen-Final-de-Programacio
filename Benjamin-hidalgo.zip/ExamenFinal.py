peliculas = {
    'P101': ['Luz de Otoño', 'drama', 110, 'B', 'Español', False],
    'P102': ['Noche Neón', 'acción', 125, 'C', 'Ingles', True],
    'P103': ['Planeta Agua', 'documental', 90, 'A', 'Español', False],
    'P104': ['Risa Total', 'comedia', 105, 'A', 'Español', True],
    'P105': ['Código Zero', 'thriller', 118, 'C', 'Ingles', True],
    'P106': ['Viaje Lunar', 'ciencia ficción', 132, 'B', 'Ingles', False]
}

cartelera = {
    'P101': [5990, 40],
    'P102': [7990, 0],
    'P103': [4990, 25],
    'P104': [6990, 12],
    'P105': [8990, 8],
    'P106': [7490, 3]
}
def cupos_genero(genero_buscado):
    total_cupos = 0
    genero_buscado = genero_buscado.lower()
    for codigo, datos in peliculas.items():
        genero_pelicula = datos[1].lower()
        if genero_pelicula == genero_buscado:
            total_cupos += cartelera[codigo][1]
    print(f"Total de cupos por el género '{genero_buscado}': {total_cupos}")

def busqueda_precio(p_min, p_max):
    resultados = []
    for codigo, datos_c in cartelera.items():
        precio = datos_c[0]
        cupos = datos_c[1]
        if p_min <= precio <= p_max and cupos > 0:
            titulo = peliculas[codigo][0]
            resultados.append(f"{titulo}--{codigo}")
    
    if not resultados:
        print("No existen peliculas con ese rango de precios.")
    else:
        resultados.sort()
        for res in resultados:
            print(res)

def actualizar_precio(codigo, nuevo_precio):
    codigo = codigo.upper()
    if codigo in cartelera:
        cartelera[codigo][0] = nuevo_precio
        return True
    return False

def validar_codigo(codigo):
    return (codigo.strip())

def validar_titulo(titulo):
    return (titulo.strip())

def validar_genero(genero):
    return (genero.strip())

def validar_duracion(duracion):
    return duracion > 0

def validar_clasificacion(clasificacion):
    return clasificacion in ['A', 'B', 'C']

def validar_idioma(idioma):
    return (idioma.strip())

def validar_es_3d(valor):
    return valor.lower() in ['s', 'n']

def validar_precio(precio):
    return precio > 0

def validar_cupos(cupos):
    return cupos >= 0
    

def agregar_pelicula(codigo, titulo, genero, duracion, clasificacion, idioma, es_3d, precio, cupos):
    codigo = codigo.upper()
    if codigo in peliculas:
        return False
    
    peliculas[codigo] = [titulo, genero, duracion, clasificacion, idioma, es_3d]
    cartelera[codigo] = [precio, cupos]
    return True

def eliminar_pelicula(codigo):
    codigo = codigo.upper()
    if codigo in peliculas:
        peliculas.pop(codigo)
        cartelera.pop(codigo)
        return True
    return False

def menu():
    while True:
        print("\n========== MENÚ PRINCIPAL ==========")
        print("1. Cupos por género")
        print("2. Búsqueda de películas por rango de precio")
        print("3. Actualizar precio de película")
        print("4. Agregar película")
        print("5. Eliminar película")
        print("6. Salir")
        
        opcion = input("Seleccione una opcion: ")

        if opcion == '1':
            genero = input("Ingrese el genero a buscar: ")
            cupos_genero(genero)

        elif opcion == '2':
            while True:
                try:
                    p_min = int(input("Ingrese precio minimo: "))
                    p_max = int(input("Ingrese precio maximo: "))
                    if p_min >= 0 and p_max >= 0 and p_min <= p_max:
                        busqueda_precio(p_min, p_max)
                        break
                    else:
                        print("Ponga solo numeros positivos y el minimo que sea menor al máximo.")
                except ValueError:
                    print("Debe ingresar valores enteros")

        elif opcion == '3':
            continuar = 's'
            while continuar.lower() == 's':
                codigo = input("Ingrese el codigo de la pelicula: ")
                try:
                    precio = int(input("Ingrese el nuevo precio: "))
                    if precio > 0:
                        exito = actualizar_precio(codigo, precio)
                        if exito:
                            print("Precio actualizado")
                        else:
                            print("Error no existe el codigo")
                    else:
                        print("El precio debe ser un entero positivo.")
                except ValueError:
                    print("Debe ingresar un valor entero para el precio.")
                
                continuar = input("Desea actualizar otro precio s/n ")

        elif opcion == '4':
            codigo = input("Codigo: ")
            if not validar_codigo(codigo):
                print("Error: El código no puede estar vacio.")
                continue
            
            titulo = input("Título: ")
            if not validar_titulo(titulo):
                print("Error: El titulo no puede estar vacio.")
                continue
            
            genero = input("Género: ")
            if not validar_genero(genero):
                print("Error: El genero no puede estar vacio.")
                continue
            
            try:
                duracion = int(input("Duración (minutos): "))
                if not validar_duracion(duracion):
                    print("Error: La duración debe ser mayor a cero.")
                    continue
            except ValueError:
                print("Error: Debe ingresar un numero entero.")
                continue
            
            clasificacion = input("Clasificación A/B/C: ").upper()
            if not validar_clasificacion(clasificacion):
                print("Error: Clasificacion no valida (Solo A B o C).")
                continue
            
            idioma = input("Idioma: ")
            if not validar_idioma(idioma):
                print("Error: El idioma no puede estar vacio.")
                continue
            
            es3d = input("Es 3D s/n: ").lower()
            if not validar_es_3d(es3d):
                print("Error: Debe ingresar 's' o 'n'.")
                continue
            es3d = True if es3d == 's' else False
            
            try:
                precio = int(input("Precio: "))
                if not validar_precio(precio):
                    print("Error: El precio debe ser mayor a cero.")
                    continue
                
                cupos = int(input("Cupos: "))
                if not validar_cupos(cupos):
                    print("Error: Los cupos no pueden ser negativos.")
                    continue
            except ValueError:
                print("Error: Precio y cupos deben ser numeros enteros.")
                continue

            if agregar_pelicula(codigo, titulo, genero, duracion, clasificacion, idioma, es3d, precio, cupos):
                print("Película agregada")
            else:
                print("El codigo ya existe")

        elif opcion == '5':
            codigo = input("Ingrese el código de la pelicula a borrar: ")
            if eliminar_pelicula(codigo):
                print("Pelicula borrada")
            else:
                print("El codigo no existe")

        elif opcion == '6':
            print("Programa terminado.")
            break
        
        else:
            print("Debe seleccionar una opción valida")

if __name__ == "__main__":
    menu()